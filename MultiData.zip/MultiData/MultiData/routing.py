import os

import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'MultiData.settings')
from channels.auth import AuthMiddlewareStack
from channels.routing import ProtocolTypeRouter, URLRouter
import app01.routing
#from app01 import consumers
django.setup()
application = ProtocolTypeRouter(
         
        {
    'websocket': AuthMiddlewareStack(
        URLRouter(
            app01.routing.websocket_urlpatterns
         #    [re_path(r'^app01/chat', consumers.ChatConsumer),]
        )
    ),
}        
)
