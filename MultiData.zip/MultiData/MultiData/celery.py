
from celery import Celery
from django.conf import settings
import os
from datetime import timedelta
#from celery.task.schedules import crontab
from celery.schedules import crontab 
# 为celery设置环境变量
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'MultiData.settings')
 
# 创建应用
#include =["CeTest.tasks"]
app = Celery("tasks")

# 配置应用
app.conf.update(
#     配置broker, 这里我们用redis作为broker
   BROKER_URL='redis://:abcdefg@10.10.102.41:6379/1',
   CELERY_RESULT_BACKEND='django-db',
#     配置定时器模块，定时器信息存储在数据库中
   CELERYBEAT_SCHEDULER='django_celery_beat.schedulers.DatabaseScheduler',
    
   CELERYBEAT_SCHEDULE = {'intervaltask':
                               {
                                   'task': 'CeTest.tasks.add',
                                   'schedule':timedelta(seconds=10),
                                   'args': (300,150)
                               },
                          'intervaltask2': 
                              {
                                  'task':'CeTest.tasks.low',
                                #  'schedule':timedelta(seconds=20),
                                 # 'schedule': crontab(minute='*/5 * * * *'),
                                  'schedule': crontab(minute=0, hour=8, day_of_week=[1, 2, 3, 4, 5]),
                                  'args': (300,150)
                              },
                         }
    
    
)
# app.conf.broker_url = 'redis://:abcdefg@10.10.102.41:6379/1'
# app.conf.result_backend = 'django-db'
# app.conf.beat_schedule = {
#     # 名字随意命名
#     'add-every-10-seconds': {
#         # 执行tasks1下的test_celery函数
#         'task': 'CeTest.tasks.low',
#         # 每隔2秒执行一次
#         # 'schedule': 1.0,
#         # 'schedule': crontab(minute="*/1"),
#         'schedule': timedelta(seconds=2),
#         # 传递参数
#         'args': (300,150)
#     },
#     # 'add-every-12-seconds': {
#     #     'task': 'celery_task.tasks1.test_celery',
#     #     每年4月11号，8点42分执行
#     #     'schedule': crontab(minute=42, hour=8,),
#     #     'args': (16, 16)
#     # },
# }

# 设置app自动加载任务
# 从已经安装的app中查找任务
app.autodiscover_tasks(settings.INSTALLED_APPS)
