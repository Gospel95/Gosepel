from django.db import models

# Create your models here.
import mongoengine

class log_info(mongoengine.Document):
    fun_name=mongoengine.StringField(max_length=100)
    dir_name = mongoengine.StringField(max_length=100)
    log_name = mongoengine.StringField(max_length=100)
    path = mongoengine.StringField(max_length=255)
    status = mongoengine.StringField(max_length=16)
    case_num=mongoengine.IntField()
    half_case_num = mongoengine.IntField()
    fail_case_num = mongoengine.IntField()
    line_num = mongoengine.IntField()

    class Meta:
        app_label = "app03"
class case_info(mongoengine.Document):
    log=mongoengine.ReferenceField(log_info)
    funtion = mongoengine.StringField(max_length=255)
    exe_status = mongoengine.StringField(max_length=16)
    line_start = mongoengine.IntField()
    line_end = mongoengine.IntField()
    error_count = mongoengine.IntField()
    level = mongoengine.IntField()
    sucess_num = mongoengine.IntField()
    fail_num = mongoengine.IntField()
    status_info = mongoengine.ListField()

    class Meta:
        app_label = "app03"
