from django.urls import path
# In routing.py
from .import views
from .import consumers
websocket_urlpatterns = [
  path('app01/ws/chat/',consumers.ChatConsumer,name="consumers"),
]
