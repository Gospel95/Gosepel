from django.db import models
APPNAME="app01"
# Create your models here.
class UsersInfo(models.Model):
    name = models.CharField(max_length=50)
    passwd = models.CharField(max_length=100)
    email =  models.CharField(max_length=100)
    def __str__(self):
        return "app01 %s " % self.name
 
    class Meta:
        app_label = "app01"
#class ShuJia(models.Model):
#    name = models.CharField(max_length=50)
#    Offset  = models.CharField(max_length=100)

 #   def __str__(self):
#        return "app01 %s " % self.name

#    class Meta:
#        app_label = "app01"
