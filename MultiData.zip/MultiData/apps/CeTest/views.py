from django.shortcuts import render

# Create your views here.

from django.shortcuts import render
from django.http import HttpResponse
from CeTest.tasks import my_task
from celery.result import AsyncResult 
from collections import defaultdict
from django_celery_results.models import TaskResult


def index(request):
# 将my_task任务加入到celery队列中
# 如果my_task函数有参数，可通过delay()传递
# 例如 my_task(a, b), my_task.delay(10, 20)
    a=6
    b=6
    task_id=my_task.delay(a,b)
   # res=AsyncResult(job) # 参数为task id
    return HttpResponse(f"<h1>服务器返回响应内容!</h1>")
def getAsyncResult(request):
    nested_dict = lambda: defaultdict(nested_dict)
    nest = nested_dict() #多级字典对象
    TaskObjs = TaskResult.objects.all()

    for obj in TaskObjs:
        task_id = obj.task_id 
        nest[task_id]["status"] = obj.status
        nest[task_id]["task_args"] = obj.task_args
        nest[task_id]["result"] = obj.result
        nest[task_id]["task_name"] = obj.task_name
    return HttpResponse(f"{dict(nest)}")     
