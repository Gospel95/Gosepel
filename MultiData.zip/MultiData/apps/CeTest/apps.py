from django.apps import AppConfig


class CeleryConfig(AppConfig):
    name = 'celery'
