from django.urls import path
from CeTest import views

app_name = 'celery'
urlpatterns = [
    path('index/', views.index, name='index'),
    path('getAsyncResult/', views.getAsyncResult, name='getAsyncResult'),
]
