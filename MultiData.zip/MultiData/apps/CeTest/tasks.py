
from MultiData.celery import app
import datetime
import time 
# 加上app对象的task装饰器
# 此函数为任务函数
@app.task
def my_task(a,b):
    print("任务开始执行....")
    time.sleep(5)
    print("任务执行结束....")
    return a+b
@app.task
def add(n,m):
    now = datetime.datetime.now()
    time.sleep(10)
    print('n+m的结果：%s' % (n + m))
    with open("CrotabTaskOut.txt","a") as f:
        f.write(str(now)+"\t"+str(n + m)+"\n")
    return n+m
@app.task
def low(n, m):
    print(n)
    print(m)
    now = datetime.datetime.now()
    print('n-m的结果：%s' % (n - m))
    with open("CrotabTaskOut.txt","a") as f:
        f.write(str(now)+"\t"+str(n - m)+"\n")
    return n - m
def interval_task_new():
    now = datetime.datetime.now()
    print(now)
    return now
