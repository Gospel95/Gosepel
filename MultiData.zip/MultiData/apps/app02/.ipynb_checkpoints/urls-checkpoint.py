from django.urls import path
from . import views

app_name = 'app02'
urlpatterns = [
    path('FindBook/', views.FindBook, name='FindBook'),
    path('InsertMango/', views.InsertMango, name='InsertMango'),
    path('CaseModified/', views.CaseModified, name='CaseModified'),
    path('CaseAbrogate/', views.CaseAbrogate, name='CaseAbrogate'),
]
