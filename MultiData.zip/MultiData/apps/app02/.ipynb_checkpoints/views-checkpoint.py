from django.shortcuts import render
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect, JsonResponse, HttpResponse
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.models import Permission
from .models import *
from app01.models import *
from app03.models import *
import json
import traceback
from django.views.decorators.csrf import csrf_exempt
#import webconfig
#print(APPNAME)
def FindBook(request):
    '''test'''
    if request.method == 'GET':
        alluser = Users.objects.using('mysql').all().exclude(username='admin')
        book    = Book.objects.filter(user_id=alluser[0].id)           
        shujia   = ShuJia.objects.all()
        email =  UsersInfo.objects.all()
    #    var = log_info.objects.create(fun_name="123", dir_name="456", log_name="11.log", path="/home",\
     #                          status="sucess",case_num=0, half_case_num=0, fail_case_num=0, line_num=0)
        log_info_obj = log_info.objects.get(log_name="12.log")
        res_dict = {"mysql中返回的name:",alluser[0].username,"sqlite中返回的:","Mango:",log_info_obj.path}
        print(alluser[0].username,shujia[0].name) 
        return JsonResponse({"response":[alluser[0].username,shujia[0].name,log_info_obj.path]})
   
def InsertMango(request):
     var = log_info.objects.create(fun_name="123", dir_name="456", log_name="12.log", path="/home",\
                               status="sucesses",case_num=0, half_case_num=0, fail_case_num=0,line_num=0)
     return JsonResponse({"response":"sucesses"})
@csrf_exempt
def CaseModified(request):
    res = {}
    param = eval(request.body)
#     param = request.POST.dict() #
    print(param)
    param_list = ["caseid","filed","values"]
    if request.method != 'POST':
        res["code"] = 405
        res["status"] = "errors"
        res["messge"] = "method is not allowed"
        return JsonResponse(res)
    else:
        if set(param_list) < set(param.keys()):#post 判断请求参数列表是不是包含所有必须参数
            res["code"] = 200
            res["status"] = "sucesses"
            res["messge"] = ""
            return JsonResponse(res)
        else:
            res["code"] = 400
            res["status"] = "errors"
            res["messge"] = "Please check whether the required parameters contain "
            return JsonResponse(res)
@csrf_exempt
def CaseAbrogate(request):
    res = {}
    param = eval(request.body)
#     param = request.POST.dict() #
    print(param)
    param_list = ["caseid","filed","values"]
    if request.method != 'POST':
        res["code"] = 405
        res["status"] = "errors"
        res["messge"] = "method is not allowed"
        return JsonResponse(res)
    else:
        if set(param_list) < set(param.keys()):
            subnumber = param["caseid"]
            try:
                #SampleNameStatus.objects.filter(subnumber=subnumber).delete()
                a = param[3]
#                 SubnumberStatus.objects.filter(subnumber=subnumber).delete()
#                 KeNuoAn.objects.filter(subnumber=subnumber).delete()
#                 GeneFilterSites.objects.filter(subnumber=subnumber).delete()
#                 BerrylyzerSites.objects.filter(subnumber=subnumber).delete()
#                 PhenolyzerSites.objects.filter(subnumber=subnumber).delete()
#                 SelectSites.objects.filter(subnumber=subnumber).delete()
#                 MT.objects.filter(subnumber=subnumber).delete()
#                 CNV.objects.filter(subnumber=subnumber).delete()
#                 SMA.objects.filter(subnumber=subnumber).delete()
#                 Extend.objects.filter(subnumber=subnumber).delete()
#                 ExonCNV.objects.filter(subnumber=subnumber).delete()
#                 UPD.objects.filter(subnumber=subnumber).delete()
#                 SendVerity.objects.filter(subnumber=subnumber).delete()
                res["code"] = 200
                res["status"] = "sucesses"
                res["messge"] = ""
                print("a",a)
            except Exception as e:
                res["code"] = 500
                res["status"] = "errors"
                res["messge"] = str(e)
                print("e",e)
        else:
            res["code"] = 400
            res["status"] = "errors"
            res["messge"] = "Please check whether the required parameters contain "
        return JsonResponse(res)


# Create your views here.
